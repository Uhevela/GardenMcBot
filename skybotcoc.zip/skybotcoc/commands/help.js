const Discord = require('discord.js'); // We need this to form & send embeds.
const { prefix } = require('../config.json');

// Command Handler
exports.run = async (client, message, args) => {

    var Help = new Discord.RichEmbed()
			.setColor('#E74C3C')
			.setTitle('Liste des commandes du SkyBot')
			.setThumbnail('https://www.stickpng.com/assets/images/584d91fc367b6a13e54477f4.png')
			.setDescription(   
			+ prefix + "poll` **:** Faire un sondage \n `",
			+ prefix + "help` **:** Cette commande, duh.")
			
			.setFooter('');
		message.channel.send(Help)

}