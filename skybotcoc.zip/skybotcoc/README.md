
## Features
- IP du serveur
- Version du serveur
- Lien du site
- Lien vers la page de vote
- Liste du staff
- Sondage (Oui/Non/Pas d'avis et choix multiples)
- Sondage + notif rôle sondages (admin only)
- Ping
- Clear, effacer les messages (nécessite la permission de 'Gérer les messages')